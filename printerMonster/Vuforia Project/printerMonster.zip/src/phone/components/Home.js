// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


$scope.switchPageVisibility = function() {
    if($scope.app.view.Home.wdg["3DImage-1"].visible){
        $scope.app.view.Home.wdg["3DImage-1"].visible = false;
    }
    else{
        $scope.app.view.Home.wdg["3DImage-1"].visible = true;
    }
};

$scope.switchInkVisibility = function() {
    if($scope.app.view.Home.wdg["3DLabel-2"].visible){
        $scope.app.view.Home.wdg["3DLabel-2"].visible = false;
    }
    else{
        $scope.app.view.Home.wdg["3DLabel-2"].visible = true;
    }
};

$scope.switchErrorVisibility = function() {
    if($scope.app.view.Home.wdg["3DLabel-4"].visible){
        $scope.app.view.Home.wdg["3DLabel-4"].visible = false;
    }
    else{
        $scope.app.view.Home.wdg["3DLabel-4"].visible = true;
    }
};

$scope.switchIPVisibility = function() {
    if($scope.app.view.Home.wdg["3DLabel-1"].visible){
        $scope.app.view.Home.wdg["3DLabel-1"].visible = false;
    }
    else{
        $scope.app.view.Home.wdg["3DLabel-1"].visible = true;
    }
};


$scope.lamp_red = function() {
  	console.log('lamp ideo red')
    $http({
    method: 'GET',
    url: 'http://as11613.itp.io:1337/lamp_ideo?value1=red'
    }).then(function successCallback(response) {
        // this callback will be called asynchronously
        // when the response is available
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
};


$scope.lamp_cyan = function() {
  	console.log('lamp ideo cyan')
    $http({
    method: 'GET',
    url: 'http://as11613.itp.io:1337/lamp_ideo?value1=cyan'
    }).then(function successCallback(response) {
        // this callback will be called asynchronously
        // when the response is available
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
};

$scope.lamp_purple = function() {
  	console.log('lamp ideo purple')
    $http({
    method: 'GET',
    url: 'http://as11613.itp.io:1337/lamp_ideo?value1=purple'
    }).then(function successCallback(response) {
        // this callback will be called asynchronously
        // when the response is available
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
};

/*http://104.236.250.123:1337/lamp_df7251*/