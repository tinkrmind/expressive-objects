// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


$scope.switchPageVisibility = function() {
    if($scope.app.view.Home.wdg["3DImage-1"].visible){
        $scope.app.view.Home.wdg["3DImage-1"].visible = false;
    }
    else{
        $scope.app.view.Home.wdg["3DImage-1"].visible = true;
    }
  	console.log('page click')
};

$scope.switchInkVisibility = function() {
    if($scope.app.view.Home.wdg["3DLabel-5"].visible){
        $scope.app.view.Home.wdg["3DLabel-5"].visible = false;
    }
    else{
        $scope.app.view.Home.wdg["3DLabel-5"].visible = true;
    }
};

$scope.switchHelloVisibility = function() {
    if($scope.app.view.Home.wdg["3DLabel-1"].visible){
        $scope.app.view.Home.wdg["3DLabel-1"].visible = false;
    }
    else{
        $scope.app.view.Home.wdg["3DLabel-1"].visible = true;
    }
};

$scope.switchErrorVisibility = function() {
    if($scope.app.view.Home.wdg["3DLabel-3"].visible){
        $scope.app.view.Home.wdg["3DLabel-3"].visible = false;
    }
    else{
        $scope.app.view.Home.wdg["3DLabel-3"].visible = true;
    }
};

$scope.switchIPVisibility = function() {
    if($scope.app.view.Home.wdg["3DLabel-4"].visible){
        $scope.app.view.Home.wdg["3DLabel-4"].visible = false;
    }
    else{
        $scope.app.view.Home.wdg["3DLabel-4"].visible = true;
    }
  	console.log('IP click')
};

$scope.wakeUp = function() {
  	$scope.app.view.Home.wdg["model-2"].visible = false;
	$scope.app.view.Home.wdg["model-3"].visible = true;
  	$scope.app.view.Home.wdg["model-4"].visible = true;
    $scope.app.view.Home.wdg["model-5"].visible = true;
    $scope.app.view.Home.wdg["model-6"].visible = true;
  	console.log('sleepy printer click');
};

