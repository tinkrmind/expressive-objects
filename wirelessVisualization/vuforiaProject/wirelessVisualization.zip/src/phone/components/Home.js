// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

connected_device = 'none'

//connect device
$scope.connect = function(device) {
  	console.log('connect'+String(device))
  
  	if(device == 'phone'){
        $scope.app.view.Home.wdg["model-3"].visible = false;
    	$scope.app.view.Home.wdg["model-2"].visible = true;
      
      	$scope.app.view.Home.wdg["model-4"].visible = true;
    	$scope.app.view.Home.wdg["model-1"].visible = false;  
    }
  
  	if(device == 'laptop'){
    	$scope.app.view.Home.wdg["model-5"].visible = false;  
    	$scope.app.view.Home.wdg["model-6"].visible = true;  
      
      	$scope.app.view.Home.wdg["model-4"].visible = true;
    	$scope.app.view.Home.wdg["model-1"].visible = false;  
    }  	
  
  	if(connected_device == 'phone'){
    	$scope.app.view.Home.wdg["model-3"].visible = true;
    	$scope.app.view.Home.wdg["model-2"].visible = false;
      	$scope.pause();
    }
  
  	if(connected_device == 'laptop'){
    	$scope.app.view.Home.wdg["model-5"].visible = true;
    	$scope.app.view.Home.wdg["model-6"].visible = false;  
      	$scope.pause();
    }
  
  	connected_device = device;
};

//connect device
$scope.disconnect = function(device) {
  	console.log('disconnect'+String(device))
  
  	if(device == 'phone'){
        $scope.app.view.Home.wdg["model-3"].visible = true;
    	$scope.app.view.Home.wdg["model-2"].visible = false;  
    }
  
  	if(device == 'laptop'){
    	$scope.app.view.Home.wdg["model-5"].visible = true;  
    	$scope.app.view.Home.wdg["model-6"].visible = false;  
    }  	
  
  	$scope.pause();
  	$scope.app.view.Home.wdg["model-1"].visible = false; 
 	$scope.app.view.Home.wdg["model-4"].visible = false; 
  
  	connected_device = 'none';
};

//play music
$scope.play = function() {
  	//check if a device is connected
	if(connected_device != 'none'){
  		$scope.app.view.Home.wdg["model-4"].visible = false;
    	$scope.app.view.Home.wdg["model-1"].visible = true;      
      	console.log('play '+String(connected_device))
        $http({
        	method: 'GET',
        	url: 'http://as11613.itp.io:1337/play?value1='+String(connected_device)
        })    
    }
  	else{
      	error();
    }
};

//pause music
$scope.pause = function() {
  	//check if a device is connected
	if(connected_device != 'none'){
  		$scope.app.view.Home.wdg["model-4"].visible = true;
    	$scope.app.view.Home.wdg["model-1"].visible = false;      
      	console.log('pause')
        $http({
        	method: 'GET',
        	url: 'http://as11613.itp.io:1337/pause'
        })    
    }
  	else{
      	error();
    }
};

error = function(){
	console.log('error');
 	$http({
        	method: 'GET',
        	url: 'http://as11613.itp.io:1337/error'
    }) 
}